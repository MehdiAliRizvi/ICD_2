from flask import Flask, request, jsonify, render_template
from pymongo import MongoClient

app = Flask(__name__)

class MongoDB:
    def __init__(self, uri, db_name, collection_name):
        self.client = MongoClient(uri)
        self.db = self.client[db_name]
        self.collection = self.db[collection_name]

    def insert_rule(self, rule_data):
        self.collection.insert_one(rule_data)

    def get_rules(self):
        return list(self.collection.find())

class RulebaseApp:
    def __init__(self, db):
        self.db = db

    def save_rule(self, rule_data):
        self.db.insert_rule(rule_data)

    def get_all_rules(self):
        return self.db.get_rules()

# Initialize MongoDB connection
mongo_db = MongoDB('mongodb://localhost:27017', 'Project1', 'Rulebase')
rulebase_app = RulebaseApp(mongo_db)

@app.route('/')
def index():
    return render_template('index.html')



@app.route('/rulebase', methods=['GET', 'POST'])
def rulebase():
    if request.method=="POST":
        print("yes")
        try:
            # Extract and validate form data
            conditions = request.form.getlist('conditions')
            disease_codes = request.form.getlist('disease_codes')
            disease_name = request.form.get('disease_name')
            
            # Collect all condition data
            condition_data = []
            for i in range(len(conditions)):
                condition = {
                    'type': conditions[i],
                    'parameter': request.form.get(f'parameter-{i+1}'),
                    'unit': request.form.get(f'unit-{i+1}'),
                    'min_value': request.form.get(f'min_values-{i+1}'),
                    'max_value': request.form.get(f'max_values-{i+1}'),
                    'operator': request.form.get(f'operator-{i+1}'),
                    'comparison_value': request.form.get(f'comparison_values-{i+1}'),
                    'age_min': request.form.get(f'age-min-{i+1}'),
                    'age_max': request.form.get(f'age-max-{i+1}'),
                    'gender': request.form.get(f'gender-{i+1}'),
                    'validity': request.form.get(f'validity-{i+1}')
                }
                condition_data.append(condition)

            rule_data = {
                'conditions': condition_data,
                'disease_codes': disease_codes,
                'disease_name': disease_name
            }
            
            print(rule_data)
            # Save to MongoDB
            rulebase_app.save_rule(rule_data)
            
            return jsonify({'status': 'success', 'message': 'Rule saved successfully!'})
        except Exception as e:
            return jsonify({'status': 'error', 'message': str(e)})
        
    return render_template('rulebase.html')




# @app.route('/rules', methods=['GET'])
# def get_rules():
#     rules = rulebase_app.get_all_rules()
#     return jsonify(rules)

if __name__ == '__main__':
    app.run(debug=True)
